
The icons used in this project are:

IconBuffet
	http://www.iconbuffet.com/
	Copyright Firewheel Design, used with permission.

Fugue Icons 0.3.5 (Beta)
	http://iconzworld.com/fugue-png-icon-set.html
	Copyright 2008 Yusuke Kamiyamane. All rights reserved.
	Licensed under a Creative Commons Attribution 3.0 licence.

 